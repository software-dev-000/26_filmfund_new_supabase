import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Film,
  Upload,
  DollarSign,
  Calendar,
  Users,
  Globe,
  Tag,
  Clock,
  FileText,
  Image as ImageIcon,
  Link as LinkIcon,
  ChevronLeft,
  Info,
  Shield,
  Wallet,
  Lock,
  Percent,
  Building2,
  Scale,
  Coins
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { useToast } from '../../contexts/ToastContext';
import { projectService } from '../../services/projectService';
import { s3Service } from '../../services/s3Service';
import { supabase } from '../../config/supabase';
import StripePaymentForm from '../payment/StripePaymentForm';

const NewProject: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const { success, error } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    title: 'ABC',
    tagline: 'EDF',
    genre: 'action',
    category: 'feature',
    fundingGoal: '100000',
    duration: '30',
    stableSplit: '70',
    synopsis: 'Synopsis',
    description: 'Description',
    coverImage: null as File | null,
    teamMembers: [{ name: 'John Doe', role: 'Director', bio: 'John Doe is a director', image: null as File | null }],
    documents: [] as File[],
    gallery: [] as File[],
    socialLinks: { website: '', twitter: '', instagram: '' },
    tokenization: {
      jurisdiction: 'us',
      legalAdvisor: 'advisor1',
      tokenizedAssets: ['Film Equity', 'Future Profits'],
      securityType: 'regD',
      maxSupply: '1000000000',
      tokenSymbol: 'FILM',
      blockchain: 'ethereum',
      lockupPeriod: '12',
      enableDividends: true,
      tradingOption: 'sto',
      whitelistOnly: true,
      tokenPrice: '1.00',
      customTerms: 'Standard terms apply. Additional conditions may be specified in the legal documentation.',
      vestingStartDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days from now
      vestingDuration: '24',
      cliffPeriod: '6',
      requireKycAml: true,
      accreditedOnly: true,
      distributionMethod: 'wallet',
      secondaryMarket: 'sto',
      spvName: 'FilmFund SPV LLC',
      legalDocuments: [] as File[]
    },
    paymentAmount: '100', // Default payment amount
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name.startsWith('tokenization.')) {
      const tokenField = name.split('.')[1];
      setFormData(prev => ({
        ...prev,
        tokenization: {
          ...prev.tokenization,
          [tokenField]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: value
      }));
    }
  };

  const handleCheckboxChange = (name: string) => {
    if (name.startsWith('tokenization.')) {
      const tokenField = name.split('.')[1];
      setFormData(prev => ({
        ...prev,
        tokenization: {
          ...prev.tokenization,
          [tokenField]: !prev.tokenization[tokenField as keyof typeof prev.tokenization]
        }
      }));
    }
  };

  const handleMultiSelect = (field: string, value: string) => {
    const currentValues = formData.tokenization[field as keyof typeof formData.tokenization] as string[];
    const updatedValues = currentValues.includes(value)
      ? currentValues.filter(v => v !== value)
      : [...currentValues, value];
    
    setFormData(prev => ({
      ...prev,
      tokenization: {
        ...prev.tokenization,
        [field]: updatedValues
      }
    }));
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    const files = e.target.files;
    if (!files) return;

    // Check file sizes (max 10MB)
    const oversizedFiles = Array.from(files).filter(file => file.size > 10 * 1024 * 1024);
    if (oversizedFiles.length > 0) {
      error('Some files were skipped because they exceed the 10MB size limit');
    }

    // Filter out oversized files
    const validFiles = Array.from(files).filter(file => file.size <= 10 * 1024 * 1024);

    if (field === 'coverImage') {
      setFormData(prev => ({ ...prev, coverImage: validFiles[0] }));
    } else if (field === 'gallery') {
      setFormData(prev => ({ ...prev, gallery: [...prev.gallery, ...validFiles] }));
    } else if (field === 'documents') {
      setFormData(prev => ({ ...prev, documents: [...prev.documents, ...validFiles] }));
    } else if (field === 'legalDocuments') {
      setFormData(prev => ({
        ...prev,
        tokenization: {
          ...prev.tokenization,
          legalDocuments: [...prev.tokenization.legalDocuments, ...validFiles]
        }
      }));
    }
  };

  const handleTeamMemberImageChange = (index: number, file: File | null) => {
    if (file) {
      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        error('Image file size must be less than 5MB');
        return;
      }

      const updatedMembers = [...formData.teamMembers];
      updatedMembers[index] = {
        ...updatedMembers[index],
        image: file
      };
      setFormData(prev => ({ ...prev, teamMembers: updatedMembers }));
    }
  };

  const handlePaymentError = (errorMessage: string) => {
    error('Payment failed', errorMessage);
  };

  const handlePaymentSuccess = async () => {
    if (!currentUser) {
      error('You must be logged in to create a project');
      return;
    }

    try {
      setIsSubmitting(true);
      
      // Check if user exists in the users table
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('id')
        .eq('id', currentUser.id)
        .single();
      
      if (userError || !userData) {
        // User doesn't exist in the users table, create them
        const { error: insertError } = await supabase
          .from('users')
          .insert({
            id: currentUser.id,
            email: currentUser.email,
            first_name: currentUser.user_metadata.first_name || '',
            last_name: currentUser.user_metadata.last_name || '',
            user_type: currentUser.user_metadata.user_type || 'filmmaker'
          });
        
        if (insertError) {
          console.error('Error creating user record:', insertError);
          error('Failed to create user record. Please try again.');
          setIsSubmitting(false);
          return;
        }
      }

      // Upload cover image if provided
      let coverImageUrl = '';
      if (formData.coverImage) {
        try {
          const result = await s3Service.uploadFile(
            'project-images',
            `${currentUser.id}/${formData.coverImage.name}`,
            formData.coverImage
          );
          coverImageUrl = result;
        } catch (err) {
          console.error('Error uploading cover image:', err);
          error('Failed to upload cover image. Please try again.');
          setIsSubmitting(false);
          return;
        }
      }

      // Upload team member images
      const teamMemberUploadPromises = formData.teamMembers
        .filter(member => member.image)
        .map(async (member) => {
          if (!member.image) return member;
          
          try {
            const result = await s3Service.uploadFile(
              'team-member-images',
              `${currentUser.id}/${member.name.replace(/\s+/g, '-').toLowerCase()}.${member.image.name.split('.').pop()}`,
              member.image
            );
            return { ...member, image_url: result };
          } catch (err) {
            console.error(`Error uploading team member image for ${member.name}:`, err);
            return member;
          }
        });

      // Upload project documents
      const documentUploadPromises = formData.documents.map(file =>
        projectService.uploadFile('project-documents', `${currentUser.id}/${file.name}`, file)
      );

      // Upload gallery images
      const galleryUploadPromises = formData.gallery.map(file =>
        projectService.uploadFile('project-gallery', `${currentUser.id}/${file.name}`, file)
      );

      // Upload legal documents
      const legalDocumentUploadPromises = formData.tokenization.legalDocuments.map(file =>
        projectService.uploadFile('legal-documents', `${currentUser.id}/${file.name}`, file)
      );

      // Wait for all uploads to complete
      const [
        teamMembersWithImages,
        documentUrls,
        galleryUrls,
        legalDocumentUrls
      ] = await Promise.all([
        Promise.all(teamMemberUploadPromises),
        Promise.all(documentUploadPromises),
        Promise.all(galleryUploadPromises),
        Promise.all(legalDocumentUploadPromises)
      ]);

      console.log('All files uploaded successfully');

      // Now create the project in the database
      console.log('Creating project in database...');
      const project = await projectService.createProject({
        filmmaker_id: currentUser.id,
        title: formData.title,
        tagline: formData.tagline,
        genre: formData.genre,
        category: formData.category as any,
        funding_goal: parseFloat(formData.fundingGoal),
        duration: parseInt(formData.duration),
        stable_split: parseInt(formData.stableSplit),
        synopsis: formData.synopsis,
        description: formData.description,
        cover_image: coverImageUrl,
        status: 'draft'
      });

      console.log('Project created successfully:', project);

      // Add team members
      const teamMemberPromises = teamMembersWithImages.map(member => {
        const teamMemberData = {
          project_id: project.id,
          name: member.name,
          role: member.role,
          bio: member.bio,
        };
        
        // Add image_url if it exists
        if ('image_url' in member) {
          return projectService.addTeamMember({
            ...teamMemberData,
            image_url: member.image_url
          });
        }
        
        return projectService.addTeamMember(teamMemberData);
      });

      // Add social links
      const socialPromises = Object.entries(formData.socialLinks)
        .filter(([_, url]) => url)
        .map(([platform, url]) => 
          projectService.addProjectSocial({
            project_id: project.id,
            platform: platform as any,
            url
          })
        );

      // Add project media (documents and gallery)
      const mediaPromises = [
        ...documentUrls.map(url => 
          projectService.addProjectMedia({
            project_id: project.id,
            type: 'document',
            url: url
          })
        ),
        ...galleryUrls.map(url => 
          projectService.addProjectMedia({
            project_id: project.id,
            type: 'image',
            url: url
          })
        )
      ];

      // Wait for all related data to be added
      await Promise.all([
        Promise.all(teamMemberPromises),
        Promise.all(socialPromises),
        Promise.all(mediaPromises)
      ]);

      console.log('All related data added successfully');

      // Create tokenization record
      await projectService.createTokenization({
        project_id: project.id,
        jurisdiction: formData.tokenization.jurisdiction,
        legal_advisor: formData.tokenization.legalAdvisor,
        tokenized_assets: formData.tokenization.tokenizedAssets,
        security_type: formData.tokenization.securityType,
        max_supply: parseInt(formData.tokenization.maxSupply),
        token_symbol: formData.tokenization.tokenSymbol,
        blockchain: formData.tokenization.blockchain,
        lockup_period: parseInt(formData.tokenization.lockupPeriod),
        enable_dividends: formData.tokenization.enableDividends,
        trading_option: formData.tokenization.tradingOption,
        whitelist_only: formData.tokenization.whitelistOnly,
        token_price: parseFloat(formData.tokenization.tokenPrice),
        custom_terms: formData.tokenization.customTerms,
        vesting_start_date: formData.tokenization.vestingStartDate,
        vesting_duration: parseInt(formData.tokenization.vestingDuration),
        cliff_period: parseInt(formData.tokenization.cliffPeriod),
        require_kyc_aml: formData.tokenization.requireKycAml,
        accredited_only: formData.tokenization.accreditedOnly,
        distribution_method: formData.tokenization.distributionMethod,
        secondary_market: formData.tokenization.secondaryMarket,
        spv_name: formData.tokenization.spvName
      });

      console.log('Tokenization record created successfully');

      success('Project created successfully!');
      navigate('/filmmaker/dashboard');
    } catch (err) {
      console.error('Failed to create project', err);
      error('Failed to create project. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const addTeamMember = () => {
    setFormData(prev => ({
      ...prev,
      teamMembers: [...prev.teamMembers, { name: '', role: '', bio: '', image: null as File | null }]
    }));
  };

  const updateTeamMember = (index: number, field: string, value: string) => {
    const newTeamMembers = [...formData.teamMembers];
    newTeamMembers[index] = { ...newTeamMembers[index], [field]: value };
    setFormData(prev => ({
      ...prev,
      teamMembers: newTeamMembers
    }));
  };

  const removeTeamMember = (index: number) => {
    setFormData(prev => ({
      ...prev,
      teamMembers: prev.teamMembers.filter((_, i) => i !== index)
    }));
  };

  const handleRemoveFile = (field: 'coverImage' | 'gallery' | 'documents' | 'legalDocuments', index?: number) => {
    if (field === 'legalDocuments') {
      setFormData(prev => ({
        ...prev,
        tokenization: {
          ...prev.tokenization,
          legalDocuments: prev.tokenization.legalDocuments.filter((_, i) => i !== index)
        }
      }));
    } else if (index !== undefined) {
      setFormData(prev => ({
        ...prev,
        [field]: (prev[field] as File[]).filter((_: File, i: number) => i !== index)
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: null
      }));
    }
    // Reset the file input
    const input = document.getElementById(field === 'coverImage' ? 'cover-image' : 
      field === 'gallery' ? 'gallery-images' : 
      field === 'legalDocuments' ? 'legal-documents' : 'project-documents') as HTMLInputElement;
    if (input) {
      input.value = '';
    }
  };

  return (
    <div className="min-h-screen bg-navy-900 text-white py-12">
      {/* Loading Overlay */}
      {isSubmitting && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
          <div className="bg-navy-800 p-8 rounded-lg shadow-xl text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-500 mx-auto mb-4"></div>
            <h3 className="text-xl font-semibold mb-2">Creating Your Project</h3>
            <p className="text-gray-400">Please wait while we process your submission...</p>
          </div>
        </div>
      )}
      
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <Link 
              to="/filmmaker/dashboard"
              className="inline-flex items-center text-gray-400 hover:text-white mb-4"
            >
              <ChevronLeft size={20} className="mr-1" />
              Back to Dashboard
            </Link>
            <h1 className="text-3xl font-bold text-white mb-2">Create New Project</h1>
            <p className="text-gray-400">
              Fill in the details below to submit your film project for funding consideration.
            </p>
          </motion.div>

          <div className="mb-8">
            <div className="flex justify-between items-center">
              {['Project Details', 'Team & Media', 'Funding & Timeline', 'Tokenization', 'Payment'].map((step, index) => (
                <div 
                  key={index}
                  className="flex-1 relative"
                >
                  <div className={`
                    h-2 ${index === 0 ? 'rounded-l-full' : index === 4 ? 'rounded-r-full' : ''}
                    ${currentStep > index + 1 ? 'bg-gold-500' : 'bg-navy-800'}
                  `}></div>
                  <div className="absolute top-4 left-0 w-full text-center">
                    <span className={`text-sm ${currentStep === index + 1 ? 'text-gold-500' : 'text-gray-400'}`}>
                      {step}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <motion.form
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            onSubmit={(e) => e.preventDefault()}
            className="space-y-8"
          >
            {currentStep === 1 && (
              <div className="space-y-6">
                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Basic Information</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="title" className="block text-sm font-medium text-gray-300 mb-1">
                        Project Title
                      </label>
                      <input
                        type="text"
                        id="title"
                        name="title"
                        value={formData.title}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                        placeholder="Enter your film's title"
                        required
                      />
                    </div>

                    <div>
                      <label htmlFor="tagline" className="block text-sm font-medium text-gray-300 mb-1">
                        Tagline
                      </label>
                      <input
                        type="text"
                        id="tagline"
                        name="tagline"
                        value={formData.tagline}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                        placeholder="A compelling one-line description"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="genre" className="block text-sm font-medium text-gray-300 mb-1">
                          Genre
                        </label>
                        <select
                          id="genre"
                          name="genre"
                          value={formData.genre}
                          onChange={handleInputChange}
                          className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                          required
                        >
                          <option value="">Select genre</option>
                          <option value="action">Action</option>
                          <option value="drama">Drama</option>
                          <option value="comedy">Comedy</option>
                          <option value="thriller">Thriller</option>
                          <option value="documentary">Documentary</option>
                          <option value="horror">Horror</option>
                        </select>
                      </div>

                      <div>
                        <label htmlFor="category" className="block text-sm font-medium text-gray-300 mb-1">
                          Category
                        </label>
                        <select
                          id="category"
                          name="category"
                          value={formData.category}
                          onChange={handleInputChange}
                          className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                          required
                        >
                          <option value="feature">Feature Film</option>
                          <option value="short">Short Film</option>
                          <option value="series">Series</option>
                          <option value="documentary">Documentary</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label htmlFor="synopsis" className="block text-sm font-medium text-gray-300 mb-1">
                        Synopsis
                      </label>
                      <textarea
                        id="synopsis"
                        name="synopsis"
                        value={formData.synopsis}
                        onChange={handleInputChange}
                        rows={3}
                        className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                        placeholder="Brief overview of your film"
                        required
                      />
                    </div>

                    <div>
                      <label htmlFor="description" className="block text-sm font-medium text-gray-300 mb-1">
                        Detailed Description
                      </label>
                      <textarea
                        id="description"
                        name="description"
                        value={formData.description}
                        onChange={handleInputChange}
                        rows={6}
                        className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                        placeholder="Detailed description of your project"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Team Members</h2>
                  
                  <div className="space-y-6">
                    {formData.teamMembers.map((member, index) => (
                      <div key={index} className="p-4 bg-navy-700 rounded-lg">
                        <div className="flex justify-between items-center mb-4">
                          <h3 className="text-white font-medium">Team Member {index + 1}</h3>
                          {index > 0 && (
                            <button
                              type="button"
                              onClick={() => removeTeamMember(index)}
                              className="text-red-400 hover:text-red-300 text-sm"
                            >
                              Remove
                            </button>
                          )}
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 mb-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">
                              Name
                            </label>
                            <input
                              type="text"
                              value={member.name}
                              onChange={(e) => updateTeamMember(index, 'name', e.target.value)}
                              className="w-full px-4 py-2 bg-navy-600 border border-navy-500 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                              placeholder="Full name"
                              required
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-300 mb-1">
                              Role
                            </label>
                            <input
                              type="text"
                              value={member.role}
                              onChange={(e) => updateTeamMember(index, 'role', e.target.value)}
                              className="w-full px-4 py-2 bg-navy-600 border border-navy-500 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                              placeholder="e.g., Director, Producer"
                              required
                            />
                          </div>
                        </div>
                        
                        <div className="mb-4">
                          <label className="block text-sm font-medium text-gray-300 mb-1">
                            Bio
                          </label>
                          <textarea
                            value={member.bio}
                            onChange={(e) => updateTeamMember(index, 'bio', e.target.value)}
                            rows={3}
                            className="w-full px-4 py-2 bg-navy-600 border border-navy-500 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                            placeholder="Brief biography and experience"
                            required
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-2">
                            Profile Image
                          </label>
                          <div className="border-2 border-dashed border-navy-600 rounded-lg p-6">
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0] || null;
                                if (file && file.size <= 5 * 1024 * 1024) { // 5MB limit
                                  handleTeamMemberImageChange(index, file);
                                } else if (file) {
                                  error('Image file size must be less than 5MB');
                                }
                              }}
                              className="hidden"
                              id={`team-member-image-${index}`}
                            />
                            <label
                              htmlFor={`team-member-image-${index}`}
                              className="flex flex-col items-center cursor-pointer"
                            >
                              {member.image ? (
                                <div className="relative w-32 h-32 mb-2">
                                  <img
                                    src={URL.createObjectURL(member.image)}
                                    alt={member.name}
                                    className="w-full h-full object-cover rounded-lg"
                                  />
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      handleTeamMemberImageChange(index, null);
                                    }}
                                    className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                                  >
                                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                      <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                    </svg>
                                  </button>
                                </div>
                              ) : (
                                <>
                                  <ImageIcon size={32} className="text-gray-400 mb-2" />
                                  <p className="text-gray-400 text-center mb-1">
                                    Click to upload profile image
                                  </p>
                                  <p className="text-sm text-gray-500 text-center">
                                    PNG, JPG or GIF (max 5MB)
                                  </p>
                                </>
                              )}
                            </label>
                          </div>
                        </div>
                      </div>
                    ))}
                    
                    <button
                      type="button"
                      onClick={addTeamMember}
                      className="w-full py-3 border-2 border-dashed border-navy-600 rounded-lg text-gray-400 hover:text-white hover:border-navy-500 transition-colors"
                    >
                      + Add Team Member
                    </button>
                  </div>
                </div>

                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Media & Documents</h2>
                  
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Cover Image
                      </label>
                      <div className="border-2 border-dashed border-navy-600 rounded-lg p-6">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleFileChange(e, 'coverImage')}
                          className="hidden"
                          id="cover-image"
                        />
                        <label
                          htmlFor="cover-image"
                          className="flex flex-col items-center cursor-pointer"
                        >
                          {formData.coverImage ? (
                            <div className="relative w-64 h-36 mb-2">
                              <img
                                src={URL.createObjectURL(formData.coverImage)}
                                alt="Cover"
                                className="w-full h-full object-cover rounded-lg"
                              />
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.preventDefault();
                                  handleRemoveFile('coverImage');
                                }}
                                className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                  <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                </svg>
                              </button>
                            </div>
                          ) : (
                            <>
                              <ImageIcon size={32} className="text-gray-400 mb-2" />
                              <p className="text-gray-400 text-center mb-1">
                                Click to upload cover image
                              </p>
                              <p className="text-sm text-gray-500 text-center">
                                PNG, JPG or GIF (max 10MB)
                              </p>
                            </>
                          )}
                        </label>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Project Gallery
                      </label>
                      <div className="border-2 border-dashed border-navy-600 rounded-lg p-6">
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          onChange={(e) => handleFileChange(e, 'gallery')}
                          className="hidden"
                          id="gallery-images"
                        />
                        <label
                          htmlFor="gallery-images"
                          className="flex flex-col items-center cursor-pointer"
                        >
                          <ImageIcon size={32} className="text-gray-400 mb-2" />
                          <p className="text-gray-400 text-center mb-1">
                            Click to upload gallery images
                          </p>
                          <p className="text-sm text-gray-500 text-center">
                            PNG, JPG or GIF (max 10MB each)
                          </p>
                        </label>
                      </div>
                      {formData.gallery.length > 0 && (
                        <div className="mt-4 grid grid-cols-3 gap-4">
                          {formData.gallery.map((file, index) => (
                            <div key={index} className="relative">
                              <img
                                src={URL.createObjectURL(file)}
                                alt={`Gallery ${index + 1}`}
                                className="w-full object-cover rounded-lg"
                              />
                              <button
                                type="button"
                                onClick={() => handleRemoveFile('gallery', index)}
                                className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                  <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                </svg>
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Project Documents
                      </label>
                      <div className="border-2 border-dashed border-navy-600 rounded-lg p-6">
                        <input
                          type="file"
                          accept=".pdf,.doc,.docx,.txt"
                          multiple
                          onChange={(e) => handleFileChange(e, 'documents')}
                          className="hidden"
                          id="project-documents"
                        />
                        <label
                          htmlFor="project-documents"
                          className="flex flex-col items-center cursor-pointer"
                        >
                          <FileText size={32} className="text-gray-400 mb-2" />
                          <p className="text-gray-400 text-center mb-1">
                            Click to upload project documents
                          </p>
                          <p className="text-sm text-gray-500 text-center">
                            PDF, DOC, DOCX or TXT (max 10MB each)
                          </p>
                        </label>
                      </div>
                      {formData.documents.length > 0 && (
                        <div className="mt-4 space-y-2">
                          {formData.documents.map((file, index) => (
                            <div key={index} className="flex items-center justify-between bg-navy-700 p-2 rounded-lg">
                              <div className="flex items-center">
                                <FileText size={16} className="text-gray-400 mr-2" />
                                <span className="text-gray-300">{file.name}</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleRemoveFile('documents', index)}
                                className="text-red-400 hover:text-red-300"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                  <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                </svg>
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Funding Details</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="fundingGoal" className="block text-sm font-medium text-gray-300 mb-1">
                        Funding Goal
                      </label>
                      <div className="relative">
                        <DollarSign size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                        <input
                          type="number"
                          id="fundingGoal"
                          name="fundingGoal"
                          value={formData.fundingGoal}
                          onChange={handleInputChange}
                          className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                          placeholder="Enter amount in USD"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label htmlFor="duration" className="block text-sm font-medium text-gray-300 mb-1">
                        Funding Duration
                      </label>
                      <div className="relative">
                        <Calendar size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                        <select
                          id="duration"
                          name="duration"
                          value={formData.duration}
                          onChange={handleInputChange}
                          className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                          required
                        >
                          <option value="">Select duration</option>
                          <option value="30">30 days</option>
                          <option value="45">45 days</option>
                          <option value="60">60 days</option>
                          <option value="90">90 days</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label htmlFor="stableSplit" className="block text-sm font-medium text-gray-300 mb-1">
                        Stablecoin Split
                      </label>
                      <div className="relative">
                        <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">%</div>
                        <input
                          type="number"
                          id="stableSplit"
                          name="stableSplit"
                          value={formData.stableSplit}
                          onChange={handleInputChange}
                          min="0"
                          max="100"
                          className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                          required
                        />
                      </div>
                      <p className="mt-1 text-sm text-gray-400">
                        Percentage of funding to be held in stablecoins
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Social Links</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="website" className="block text-sm font-medium text-gray-300 mb-1">
                        Website
                      </label>
                      <div className="relative">
                        <Globe size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                        <input
                          type="url"
                          id="website"
                          name="website"
                          value={formData.socialLinks.website}
                          onChange={(e) => setFormData(prev => ({
                            ...prev,
                            socialLinks: { ...prev.socialLinks, website: e.target.value }
                          }))}
                          className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                          placeholder="https://"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="twitter" className="block text-sm font-medium text-gray-300 mb-1">
                          Twitter
                        </label>
                        <div className="relative">
                          <LinkIcon size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                          <input
                            type="url"
                            id="twitter"
                            name="twitter"
                            value={formData.socialLinks.twitter}
                            onChange={(e) => setFormData(prev => ({
                              ...prev,
                              socialLinks: { ...prev.socialLinks, twitter: e.target.value }
                            }))}
                            className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                            placeholder="Twitter URL"
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="instagram" className="block text-sm font-medium text-gray-300 mb-1">
                          Instagram
                        </label>
                        <div className="relative">
                          <LinkIcon size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                          <input
                            type="url"
                            id="instagram"
                            name="instagram"
                            value={formData.socialLinks.instagram}
                            onChange={(e) => setFormData(prev => ({
                              ...prev,
                              socialLinks: { ...prev.socialLinks, instagram: e.target.value }
                            }))}
                            className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                            placeholder="Instagram URL"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-6">
                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Token Structure</h2>
                  
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="tokenization.jurisdiction" className="block text-sm font-medium text-gray-300 mb-1">
                          Token Jurisdiction
                        </label>
                        <div className="relative">
                          <Building2 size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                          <select
                            id="tokenization.jurisdiction"
                            name="tokenization.jurisdiction"
                            value={formData.tokenization.jurisdiction}
                            onChange={handleInputChange}
                            className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                            required
                          >
                            <option value="">Select jurisdiction</option>
                            <option value="us">United States</option>
                            <option value="eu">European Union</option>
                            <option value="uk">United Kingdom</option>
                            <option value="sg">Singapore</option>
                            <option value="ch">Switzerland</option>
                            <option value="ky">Cayman Islands</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label htmlFor="tokenization.legalAdvisor" className="block text-sm font-medium text-gray-300 mb-1">
                          Legal Advisor
                        </label>
                        <div className="relative">
                          <Scale size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                          <select
                            id="tokenization.legalAdvisor"
                            name="tokenization.legalAdvisor"
                            value={formData.tokenization.legalAdvisor}
                            onChange={handleInputChange}
                            className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                            required
                          >
                            <option value="">Select advisor</option>
                            <option value="advisor1">Smith & Associates LLP</option>
                            <option value="advisor2">Global Securities Law Group</option>
                            <option value="advisor3">Blockchain Legal Partners</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        What Will Be Tokenized
                      </label>
                      <div className="grid grid-cols-2 gap-3">
                        {['Film Equity', 'Future Profits', 'IP Rights', 'Distribution Rights'].map((asset) => (
                          <label
                            key={asset}
                            className="flex items-center p-3 bg-navy-700 rounded-lg cursor-pointer hover:bg-navy-600 transition-colors"
                          >
                            <input
                              type="checkbox"
                              checked={formData.tokenization.tokenizedAssets.includes(asset)}
                              onChange={() => handleMultiSelect('tokenizedAssets', asset)}
                              className="h-4 w-4 text-gold-500 rounded border-navy-600 focus:ring-gold-500"
                            />
                            <span className="ml-2 text-white">{asset}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="tokenization.securityType" className="block text-sm font-medium text-gray-300 mb-1">
                          Security Token Type
                        </label>
                        <div className="relative">
                          <Shield size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                          <select
                            id="tokenization.securityType"
                            name="tokenization.securityType"
                            value={formData.tokenization.securityType}
                            onChange={handleInputChange}
                            className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                            required
                          >
                            <option value="">Select type</option>
                            <option value="regD">Reg D</option>
                            <option value="regS">Reg S</option>
                            <option value="regA">Reg A+</option>
                            <option value="regCF">Reg CF</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label htmlFor="tokenization.blockchain" className="block text-sm font-medium text-gray-300 mb-1">
                          Blockchain Platform
                        </label>
                        <div className="relative">
                          <Wallet size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                          <select
                            id="tokenization.blockchain"
                            name="tokenization.blockchain"
                            value={formData.tokenization.blockchain}
                            onChange={handleInputChange}
                            className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                            required
                          >
                            <option value="">Select blockchain</option>
                            <option value="polygon">Polygon</option>
                            <option value="ethereum">Ethereum</option>
                            <option value="bsc">BSC</option>
                            <option value="solana">Solana</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="tokenization.maxSupply" className="block text-sm font-medium text-gray-300 mb-1">
                          Maximum Token Supply
                        </label>
                        <div className="relative">
                          <Coins size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                          <input
                            type="number"
                            id="tokenization.maxSupply"
                            name="tokenization.maxSupply"
                            value={formData.tokenization.maxSupply}
                            onChange={handleInputChange}
                            className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                            placeholder="e.g., 1000000"
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="tokenization.tokenSymbol" className="block text-sm font-medium text-gray-300 mb-1">
                          Token Symbol
                        </label>
                        <div className="relative">
                          <Tag size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                          <input
                            type="text"
                            id="tokenization.tokenSymbol"
                            name="tokenization.tokenSymbol"
                            value={formData.tokenization.tokenSymbol}
                            onChange={handleInputChange}
                            className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                            placeholder="e.g., FILM"
                            required
                          />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="tokenization.lockupPeriod" className="block text-sm font-medium text-gray-300 mb-1">
                          Lock-up Period (months)
                        </label>
                        <div className="relative">
                          <Lock size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                          <input
                            type="number"
                            id="tokenization.lockupPeriod"
                            name="tokenization.lockupPeriod"
                            value={formData.tokenization.lockupPeriod}
                            onChange={handleInputChange}
                            className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                            placeholder="e.g., 12"
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="tokenization.tokenPrice" className="block text-sm font-medium text-gray-300 mb-1">
                          Token Price (USD)
                        </label>
                        <div className="relative">
                          <DollarSign size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                          <input
                            type="number"
                            step="0.01"
                            id="tokenization.tokenPrice"
                            name="tokenization.tokenPrice"
                            value={formData.tokenization.tokenPrice}
                            onChange={handleInputChange}
                            className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                            placeholder="e.g., 1.00"
                            required
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label htmlFor="tokenization.tradingOption" className="block text-sm font-medium text-gray-300 mb-1">
                        Transfer/Trading Options
                      </label>
                      <div className="relative">
                        <Globe size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                        <select
                          id="tokenization.tradingOption"
                          name="tokenization.tradingOption"
                          value={formData.tokenization.tradingOption}
                          onChange={handleInputChange}
                          className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                          required
                        >
                          <option value="">Select option</option>
                          <option value="sto">STO Exchange</option>
                          <option value="p2p">P2P with KYC</option>
                          <option value="locked">Not Tradable</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="flex items-center space-x-3">
                        <input
                          type="checkbox"
                          checked={formData.tokenization.enableDividends}
                          onChange={() => handleCheckboxChange('tokenization.enableDividends')}
                          className="h-4 w-4 text-gold-500 rounded border-navy-600 focus:ring-gold-500"
                        />
                        <span className="text-white">Enable Dividend Distribution</span>
                      </label>

                      <label className="flex items-center space-x-3">
                        <input
                          type="checkbox"
                          checked={formData.tokenization.whitelistOnly}
                          onChange={() => handleCheckboxChange('tokenization.whitelistOnly')}
                          className="h-4 w-4 text-gold-500 rounded border-navy-600 focus:ring-gold-500"
                        />
                        <span className="text-white">Whitelisted Transfers Only</span>
                      </label>
                    </div>

                    <div>
                      <label htmlFor="tokenization.customTerms" className="block text-sm font-medium text-gray-300 mb-1">
                        Additional Terms
                      </label>
                      <textarea
                        id="tokenization.customTerms"
                        name="tokenization.customTerms"
                        value={formData.tokenization.customTerms}
                        onChange={handleInputChange}
                        rows={4}
                        className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                        placeholder="Enter any additional terms or custom conditions..."
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Vesting Schedule</h2>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label htmlFor="tokenization.vestingStartDate" className="block text-sm font-medium text-gray-300 mb-1">
                        Vesting Start Date
                      </label>
                      <input
                        type="date"
                        id="tokenization.vestingStartDate"
                        name="tokenization.vestingStartDate"
                        value={formData.tokenization.vestingStartDate}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="tokenization.vestingDuration" className="block text-sm font-medium text-gray-300 mb-1">
                        Vesting Duration (months)
                      </label>
                      <input
                        type="number"
                        id="tokenization.vestingDuration"
                        name="tokenization.vestingDuration"
                        value={formData.tokenization.vestingDuration}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                        placeholder="e.g., 24"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="tokenization.cliffPeriod" className="block text-sm font-medium text-gray-300 mb-1">
                        Cliff Period (months)
                      </label>
                      <input
                        type="number"
                        id="tokenization.cliffPeriod"
                        name="tokenization.cliffPeriod"
                        value={formData.tokenization.cliffPeriod}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                        placeholder="e.g., 6"
                      />
                    </div>
                  </div>
                </div>

                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Compliance Requirements</h2>
                  
                  <div className="space-y-4">
                    <label className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        checked={formData.tokenization.requireKycAml}
                        onChange={() => handleCheckboxChange('tokenization.requireKycAml')}
                        className="h-4 w-4 text-gold-500 rounded border-navy-600 focus:ring-gold-500"
                      />
                      <span className="text-white">KYC/AML Requirement</span>
                    </label>

                    <label className="flex items-center space-x-3">
                      <input
                        type="checkbox"
                        checked={formData.tokenization.accreditedOnly}
                        onChange={() => handleCheckboxChange('tokenization.accreditedOnly')}
                        className="h-4 w-4 text-gold-500 rounded border-navy-600 focus:ring-gold-500"
                      />
                      <span className="text-white">Accredited Investors Only</span>
                    </label>
                  </div>
                </div>

                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Distribution and Trading</h2>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="tokenization.distributionMethod" className="block text-sm font-medium text-gray-300 mb-1">
                        Token Distribution Method
                      </label>
                      <select
                        id="tokenization.distributionMethod"
                        name="tokenization.distributionMethod"
                        value={formData.tokenization.distributionMethod}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                        required
                      >
                        <option value="">Select method</option>
                        <option value="wallet">Direct Wallet Transfer</option>
                        <option value="custodial">Custodial Service</option>
                        <option value="vesting">Vesting Contract</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="tokenization.secondaryMarket" className="block text-sm font-medium text-gray-300 mb-1">
                        Secondary Market Listing
                      </label>
                      <select
                        id="tokenization.secondaryMarket"
                        name="tokenization.secondaryMarket"
                        value={formData.tokenization.secondaryMarket}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                        required
                      >
                        <option value="">Select listing plan</option>
                        <option value="sto">STO Exchange</option>
                        <option value="p2p">P2P with KYC</option>
                        <option value="none">No Listing Planned</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Legal Entity</h2>
                  
                  <div>
                    <label htmlFor="tokenization.spvName" className="block text-sm font-medium text-gray-300 mb-1">
                      SPV or Legal Entity Name
                    </label>
                    <input
                      type="text"
                      id="tokenization.spvName"
                      name="tokenization.spvName"
                      value={formData.tokenization.spvName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                      placeholder="Enter legal entity name"
                    />
                    <p className="mt-1 text-sm text-gray-400">
                      This entity will be registered or used by the legal advisor for token issuance
                    </p>
                  </div>
                </div>

                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Legal Documents</h2>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Upload Legal Documents
                    </label>
                    <div className="border-2 border-dashed border-navy-600 rounded-lg p-6">
                      <input
                        type="file"
                        accept=".pdf"
                        multiple
                        onChange={(e) => handleFileChange(e, 'legalDocuments')}
                        className="hidden"
                        id="legal-documents"
                      />
                      <label
                        htmlFor="legal-documents"
                        className="flex flex-col items-center cursor-pointer"
                      >
                        <FileText size={32} className="text-gray-400 mb-2" />
                        <p className="text-gray-400 text-center mb-1">
                          Click to upload or drag and drop
                        </p>
                        <p className="text-sm text-gray-500 text-center">
                          PDF files only, max 10MB each
                        </p>
                      </label>
                      {formData.tokenization.legalDocuments.length > 0 && (
                        <div className="mt-4 space-y-2">
                          {formData.tokenization.legalDocuments.map((file, index) => (
                            <div key={index} className="flex items-center justify-between bg-navy-700 p-2 rounded-lg">
                              <div className="flex items-center">
                                <FileText size={16} className="text-gray-400 mr-2" />
                                <span className="text-gray-300">{file.name}</span>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleRemoveFile('legalDocuments', index)}
                                className="text-red-400 hover:text-red-300"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                                  <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                                </svg>
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 5 && (
              <div className="space-y-6">
                <div className="bg-navy-800 rounded-xl p-6 border border-navy-700">
                  <h2 className="text-xl font-bold text-white mb-4">Payment</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="paymentAmount" className="block text-sm font-medium text-gray-300 mb-1">
                        Payment Amount (USD)
                      </label>
                      <div className="relative">
                        <DollarSign size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                        <input
                          type="number"
                          id="paymentAmount"
                          name="paymentAmount"
                          value={formData.paymentAmount}
                          onChange={handleInputChange}
                          className="w-full pl-10 pr-4 py-2 bg-navy-700 border border-navy-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-gold-500"
                          placeholder="Enter amount"
                          required
                          min="1"
                          step="0.01"
                        />
                      </div>
                      <p className="mt-1 text-sm text-gray-400">
                        This fee covers the cost of processing your project submission
                      </p>
                    </div>

                    <StripePaymentForm
                      amount={parseFloat(formData.paymentAmount)}
                      onSuccess={handlePaymentSuccess}
                      onCancel={() => setCurrentStep(4)}
                      onError={handlePaymentError}
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-between pt-6">
              {currentStep > 1 && (
                <button
                  type="button"
                  onClick={() => setCurrentStep(currentStep - 1)}
                  className="px-6 py-2 border border-navy-600 text-white rounded-lg hover:bg-navy-800 transition-colors"
                >
                  Previous
                </button>
              )}
              
              {currentStep < 5 ? (
                <button
                  type="button"
                  onClick={() => setCurrentStep(currentStep + 1)}
                  className="px-6 py-2 bg-gold-500 text-navy-900 rounded-lg hover:bg-gold-600 transition-colors ml-auto"
                >
                  Next
                </button>
              ) : null}
            </div>
          </motion.form>
        </div>
      </div>
    </div>
  );
};

export default NewProject;