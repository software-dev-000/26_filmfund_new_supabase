import React from 'react';
import { motion } from 'framer-motion';
import { 
  Film, 
  DollarSign, 
  Users, 
  Clock, 
  Globe,
  FileText,
  Calendar,
  TrendingUp,
  Shield,
  ChevronRight,
  PlayCircle,
  User,
  Briefcase,
  Target,
  PieChart
} from 'lucide-react';
import { Link } from 'react-router-dom';  

const ProjectView: React.FC = () => {
  // Mock data - in a real app, this would come from your API
  const project = {
    id: 1,
    title: "The Last Horizon",
    tagline: "A groundbreaking sci-fi thriller that pushes the boundaries of human exploration",
    coverImage: "https://images.pexels.com/photos/1117132/pexels-photo-1117132.jpeg",
    genre: "Science Fiction",
    stage: "Pre-Production",
    budget: 2500000,
    fundingRaised: 1750000,
    minInvestment: 5000,
    maxInvestment: 250000,
    daysLeft: 23,
    investors: 156,
    jurisdiction: "United States",
    lawyer: "Smith & Associates LLP",
    team: [
      {
        name: "Elena Rodriguez",
        role: "Director",
        image: "https://images.pexels.com/photos/3796217/pexels-photo-3796217.jpeg",
        bio: "Award-winning director with over 15 years of experience in sci-fi films."
      },
      {
        name: "Michael Chen",
        role: "Producer",
        image: "https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg",
        bio: "Veteran producer with successful track record in independent films."
      },
      {
        name: "Sarah Johnson",
        role: "Cinematographer",
        image: "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg",
        bio: "Innovative cinematographer known for stunning visual storytelling."
      }
    ],
    gallery: [
      "https://images.pexels.com/photos/2873486/pexels-photo-2873486.jpeg",
      "https://images.pexels.com/photos/3062541/pexels-photo-3062541.jpeg",
      "https://images.pexels.com/photos/2873479/pexels-photo-2873479.jpeg"
    ],
    timeline: [
      {
        phase: "Pre-Production",
        date: "Q2 2025",
        status: "In Progress",
        milestones: ["Script finalization", "Location scouting", "Cast selection"]
      },
      {
        phase: "Production",
        date: "Q3-Q4 2025",
        status: "Upcoming",
        milestones: ["Principal photography", "Special effects filming"]
      },
      {
        phase: "Post-Production",
        date: "Q1 2026",
        status: "Upcoming",
        milestones: ["Editing", "VFX", "Sound design"]
      },
      {
        phase: "Distribution",
        date: "Q2 2026",
        status: "Upcoming",
        milestones: ["Festival circuit", "Theatrical release", "Streaming platform launch"]
      }
    ],
    useOfProceeds: [
      { category: "Production Costs", percentage: 60 },
      { category: "Post-Production", percentage: 20 },
      { category: "Marketing", percentage: 15 },
      { category: "Legal & Admin", percentage: 5 }
    ],
    projectedReturns: {
      conservative: 15,
      target: 25,
      optimistic: 40
    },
    securityToken: {
      type: "Revenue Share Token",
      platform: "Ethereum",
      rights: [
        "Pro-rata share of film revenue",
        "Exclusive NFT collection access",
        "Film premiere tickets",
        "Behind-the-scenes content"
      ]
    }
  };

  const percentFunded = Math.round((project.fundingRaised / project.budget) * 100);

  return (
    <div className="min-h-screen bg-navy-950 pt-20">
      {/* Hero Section */}
      <section className="relative h-[60vh] min-h-[400px]">
        <div className="absolute inset-0">
          <img 
            src={project.coverImage} 
            alt={project.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-navy-950 to-transparent"></div>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <div className="container mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-3">
                {project.title}
              </h1>
              <p className="text-xl text-gray-300 mb-6">
                {project.tagline}
              </p>
              
              <div className="flex flex-wrap gap-4 text-sm">
                <span className="bg-navy-800/80 backdrop-blur-sm text-white px-3 py-1 rounded-full">
                  {project.genre}
                </span>
                <span className="bg-navy-800/80 backdrop-blur-sm text-white px-3 py-1 rounded-full">
                  {project.stage}
                </span>
                <span className="bg-navy-800/80 backdrop-blur-sm text-white px-3 py-1 rounded-full">
                  Budget: ${(project.budget / 1000000).toFixed(1)}M
                </span>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 md:px-6 mt-[50px]">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 -mt-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Funding Progress */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-navy-800 rounded-xl p-6 border border-navy-700"
            >
              <div className="flex justify-between items-end mb-4">
                <div>
                  <h3 className="text-xl font-bold text-white">
                    ${(project.fundingRaised / 1000000).toFixed(1)}M
                  </h3>
                  <p className="text-gray-400">raised of ${(project.budget / 1000000).toFixed(1)}M goal</p>
                </div>
                <div className="text-right">
                  <p className="text-gold-500 font-bold">{percentFunded}%</p>
                  <p className="text-gray-400">{project.daysLeft} days left</p>
                </div>
              </div>
              
              <div className="w-full bg-navy-700 rounded-full h-2 mb-4">
                <div 
                  className="bg-gold-500 h-2 rounded-full" 
                  style={{ width: `${percentFunded}%` }}
                ></div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-navy-700 rounded-lg p-4">
                  <div className="flex items-center text-gray-400 mb-1">
                    <Users size={16} className="mr-2" />
                    Investors
                  </div>
                  <p className="text-xl font-bold text-white">{project.investors}</p>
                </div>
                <div className="bg-navy-700 rounded-lg p-4">
                  <div className="flex items-center text-gray-400 mb-1">
                    <DollarSign size={16} className="mr-2" />
                    Investment Range
                  </div>
                  <p className="text-xl font-bold text-white">
                    ${(project.minInvestment / 1000).toFixed(1)}K - ${(project.maxInvestment / 1000).toFixed(1)}K
                  </p>
                </div>
              </div>
              
              <button className="w-full bg-gold-500 hover:bg-gold-600 text-navy-900 py-3 rounded-lg font-medium transition-colors">
                Invest Now
              </button>
            </motion.div>

            {/* Project Overview */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-navy-800 rounded-xl p-6 border border-navy-700"
            >
              <h2 className="text-2xl font-bold text-white mb-4">Project Overview</h2>
              <div className="aspect-video mb-6 bg-navy-700 rounded-lg overflow-hidden">
                <img 
                  src={project.gallery[0]} 
                  alt="Project Overview" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                {project.gallery.map((image, index) => (
                  <div key={index} className="aspect-video bg-navy-700 rounded-lg overflow-hidden">
                    <img 
                      src={image} 
                      alt={`Gallery ${index + 1}`} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Team */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-navy-800 rounded-xl p-6 border border-navy-700"
            >
              <h2 className="text-2xl font-bold text-white mb-6">Meet the Team</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {project.team.map((member, index) => (
                  <div key={index} className="text-center">
                    <div className="w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden">
                      <img 
                        src={member.image} 
                        alt={member.name} 
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <h3 className="text-lg font-bold text-white mb-1">{member.name}</h3>
                    <p className="text-gold-500 mb-2">{member.role}</p>
                    <p className="text-gray-400 text-sm">{member.bio}</p>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Timeline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-navy-800 rounded-xl p-6 border border-navy-700"
            >
              <h2 className="text-2xl font-bold text-white mb-6">Project Timeline</h2>
              <div className="space-y-6">
                {project.timeline.map((phase, index) => (
                  <div key={index} className="flex">
                    <div className="flex-shrink-0 w-32 pt-1">
                      <p className="text-gold-500 font-medium">{phase.date}</p>
                    </div>
                    <div className="flex-grow pl-6 border-l border-navy-700">
                      <h3 className="text-lg font-bold text-white mb-2">{phase.phase}</h3>
                      <div className="space-y-2">
                        {phase.milestones.map((milestone, i) => (
                          <div key={i} className="flex items-center text-gray-400">
                            <ChevronRight size={16} className="mr-2" />
                            {milestone}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Legal & Jurisdiction */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-navy-800 rounded-xl p-6 border border-navy-700"
            >
              <h2 className="text-xl font-bold text-white mb-4">Legal Information</h2>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center text-gray-400 mb-1">
                    <Globe size={16} className="mr-2" />
                    Jurisdiction
                  </div>
                  <p className="text-white">{project.jurisdiction}</p>
                </div>
                <div>
                  <div className="flex items-center text-gray-400 mb-1">
                    <Shield size={16} className="mr-2" />
                    Legal Counsel
                  </div>
                  <p className="text-white">{project.lawyer}</p>
                </div>
              </div>
            </motion.div>

            {/* Security Token Details */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-navy-800 rounded-xl p-6 border border-navy-700"
            >
              <h2 className="text-xl font-bold text-white mb-4">Security Token</h2>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center text-gray-400 mb-1">
                    <FileText size={16} className="mr-2" />
                    Token Type
                  </div>
                  <p className="text-white">{project.securityToken.type}</p>
                </div>
                <div>
                  <div className="flex items-center text-gray-400 mb-1">
                    <Shield size={16} className="mr-2" />
                    Token Rights
                  </div>
                  <ul className="space-y-2">
                    {project.securityToken.rights.map((right, index) => (
                      <li key={index} className="flex items-center text-white">
                        <ChevronRight size={16} className="text-gold-500 mr-2" />
                        {right}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>

            {/* Use of Proceeds */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-navy-800 rounded-xl p-6 border border-navy-700"
            >
              <h2 className="text-xl font-bold text-white mb-4">Use of Proceeds</h2>
              <div className="space-y-4">
                {project.useOfProceeds.map((item, index) => (
                  <div key={index}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-400">{item.category}</span>
                      <span className="text-white">{item.percentage}%</span>
                    </div>
                    <div className="w-full bg-navy-700 rounded-full h-2">
                      <div 
                        className="bg-gold-500 h-2 rounded-full" 
                        style={{ width: `${item.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>

            {/* Projected Returns */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-navy-800 rounded-xl p-6 border border-navy-700"
            >
              <h2 className="text-xl font-bold text-white mb-4">Projected Returns</h2>
              <div className="space-y-4">
                <div className="bg-navy-700 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-400">Conservative</span>
                    <span className="text-white font-bold">{project.projectedReturns.conservative}%</span>
                  </div>
                  <div className="w-full bg-navy-600 rounded-full h-2">
                    <div 
                      className="bg-blue-500 h-2 rounded-full" 
                      style={{ width: `${project.projectedReturns.conservative}%` }}
                    ></div>
                  </div>
                </div>
                <div className="bg-navy-700 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-400">Target</span>
                    <span className="text-white font-bold">{project.projectedReturns.target}%</span>
                  </div>
                  <div className="w-full bg-navy-600 rounded-full h-2">
                    <div 
                      className="bg-gold-500 h-2 rounded-full" 
                      style={{ width: `${project.projectedReturns.target}%` }}
                    ></div>
                  </div>
                </div>
                <div className="bg-navy-700 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-400">Optimistic</span>
                    <span className="text-white font-bold">{project.projectedReturns.optimistic}%</span>
                  </div>
                  <div className="w-full bg-navy-600 rounded-full h-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full" 
                      style={{ width: `${project.projectedReturns.optimistic}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectView;