import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Film, 
  Filter,
  Search,
  ChevronDown,
  Users,
  Clock,
  DollarSign
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface Project {
  id: number;
  title: string;
  category: string;
  type: string;
  genre: string;
  director: string;
  fundingGoal: number;
  fundingRaised: number;
  investors: number;
  daysLeft: number;
  image: string;
}

const ProjectsPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  const categories = [
    { id: 'all', name: 'All Categories' },
    { id: 'action', name: 'Action Films' },
    { id: 'romance', name: 'Love Stories' },
    { id: 'drama', name: 'Drama' },
    { id: 'documentary', name: 'Documentary' },
    { id: 'thriller', name: 'Thriller' },
    { id: 'comedy', name: 'Comedy' }
  ];
  
  const types = [
    { id: 'all', name: 'All Types' },
    { id: 'independent', name: 'Independent Filmmaker' },
    { id: 'studio', name: 'Studio Production' },
    { id: 'emerging', name: 'Emerging Talent' }
  ];
  
  const projects: Project[] = [
    {
      id: 1,
      title: "The Last Horizon",
      category: "action",
      type: "studio",
      genre: "Sci-Fi Action",
      director: "Elena Rodriguez",
      fundingGoal: 2500000,
      fundingRaised: 1750000,
      investors: 156,
      daysLeft: 23,
      image: "https://images.pexels.com/photos/1117132/pexels-photo-1117132.jpeg"
    },
    {
      id: 2,
      title: "Whispers of Love",
      category: "romance",
      type: "independent",
      genre: "Romance Drama",
      director: "Michael Chen",
      fundingGoal: 850000,
      fundingRaised: 650000,
      investors: 78,
      daysLeft: 15,
      image: "https://images.pexels.com/photos/1024992/pexels-photo-1024992.jpeg"
    },
    {
      id: 3,
      title: "Urban Legends",
      category: "thriller",
      type: "emerging",
      genre: "Psychological Thriller",
      director: "Sarah Johnson",
      fundingGoal: 1200000,
      fundingRaised: 480000,
      investors: 53,
      daysLeft: 34,
      image: "https://images.pexels.com/photos/3052361/pexels-photo-3052361.jpeg"
    }
  ];
  
  const filteredProjects = projects.filter(project => {
    const matchesCategory = selectedCategory === 'all' || project.category === selectedCategory;
    const matchesType = selectedType === 'all' || project.type === selectedType;
    const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.director.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesType && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-navy-950 py-20">
      <div className="container mx-auto px-4 md:px-6">
        <div className="mb-12">
          <motion.h1 
            className="text-4xl font-bold text-white mb-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            Film Projects
          </motion.h1>
          <motion.p 
            className="text-gray-400"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            Discover and invest in groundbreaking film projects from around the world.
          </motion.p>
        </div>
        
        <motion.div 
          className="bg-navy-900 rounded-xl p-6 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-grow relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search projects or directors..."
                className="w-full bg-navy-800 text-white rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-gold-500"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="flex gap-4">
              <div className="relative">
                <select
                  className="appearance-none bg-navy-800 text-white rounded-lg pl-4 pr-10 py-2 focus:outline-none focus:ring-2 focus:ring-gold-500"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                >
                  {categories.map(category => (
                    <option key={category.id} value={category.id}>{category.name}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              </div>
              
              <div className="relative">
                <select
                  className="appearance-none bg-navy-800 text-white rounded-lg pl-4 pr-10 py-2 focus:outline-none focus:ring-2 focus:ring-gold-500"
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                >
                  {types.map(type => (
                    <option key={type.id} value={type.id}>{type.name}</option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
              </div>
            </div>
          </div>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>
      </div>
    </div>
  );
};

interface ProjectCardProps {
  project: Project;
  index: number;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, index }) => {
  const percentFunded = Math.round((project.fundingRaised / project.fundingGoal) * 100);
  
  return (
    <motion.div 
      className="bg-navy-800 rounded-xl overflow-hidden border border-navy-700 hover:border-navy-600 transition-colors"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.1 * index }}
    >
      <div className="relative h-48">
        <img 
          src={project.image} 
          alt={project.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-3 right-3">
          <span className="inline-block px-2 py-1 text-xs rounded-full bg-navy-900/80 text-white backdrop-blur-sm">
            {project.type}
          </span>
        </div>
        <div className="absolute bottom-3 left-3">
          <span className="inline-block px-2 py-1 text-xs rounded-full bg-navy-900/80 text-white backdrop-blur-sm">
            {project.genre}
          </span>
        </div>
      </div>
      
      <div className="p-5">
        <h3 className="text-xl font-bold text-white mb-1">{project.title}</h3>
        <p className="text-gray-400 text-sm mb-4">Directed by {project.director}</p>
        
        <div className="mb-4">
          <div className="flex justify-between text-sm mb-1">
            <span className="text-gray-400">Funding Progress</span>
            <span className="text-gold-500">{percentFunded}%</span>
          </div>
          <div className="w-full bg-navy-700 rounded-full h-2">
            <div 
              className="bg-gold-500 h-2 rounded-full" 
              style={{ width: `${percentFunded}%` }}
            ></div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-3 text-sm mb-4">
          <div className="flex items-center">
            <DollarSign size={14} className="text-gold-500 mr-1" />
            <span className="text-gray-300">${(project.fundingRaised / 1000000).toFixed(1)}M raised</span>
          </div>
          <div className="flex items-center">
            <Users size={14} className="text-gold-500 mr-1" />
            <span className="text-gray-300">{project.investors} investors</span>
          </div>
          <div className="flex items-center">
            <DollarSign size={14} className="text-gold-500 mr-1" />
            <span className="text-gray-300">${(project.fundingGoal / 1000000).toFixed(1)}M goal</span>
          </div>
          <div className="flex items-center">
            <Clock size={14} className="text-gold-500 mr-1" />
            <span className="text-gray-300">{project.daysLeft} days left</span>
          </div>
        </div>
        
        <Link 
          to={`/projects/${project.id}`}
          className="block w-full bg-navy-700 hover:bg-navy-600 text-white text-center py-2 rounded-md transition-colors"
        >
          View Details
        </Link>
      </div>
    </motion.div>
  );
};

export default ProjectsPage;