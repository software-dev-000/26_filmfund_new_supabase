import { supabase } from '../config/supabase';
import { s3Service } from './s3Service';
import { 
  Project, 
  TeamMember, 
  ProjectMedia, 
  ProjectSocial, 
  Tokenization,
  ProjectMilestone,
  ProjectUpdate,
  ProjectComment
} from '../types/database';

export const projectService = {
  // Project CRUD operations
  async createProject(project: Omit<Project, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('projects')
      .insert(project)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async getProject(id: string) {
    const { data, error } = await supabase
      .from('projects')
      .select(`
        *,
        team_members (*),
        project_media (*),
        project_social (*),
        tokenization (*),
        project_milestones (*),
        project_updates (*),
        project_comments (*)
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  },

  async updateProject(id: string, updates: Partial<Project>) {
    const { data, error } = await supabase
      .from('projects')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteProject(id: string) {
    const { error } = await supabase
      .from('projects')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  // Team members operations
  async addTeamMember(teamMember: Omit<TeamMember, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('team_members')
      .insert(teamMember)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateTeamMember(id: string, updates: Partial<TeamMember>) {
    const { data, error } = await supabase
      .from('team_members')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteTeamMember(id: string) {
    const { error } = await supabase
      .from('team_members')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  // Project media operations
  async addProjectMedia(media: Omit<ProjectMedia, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('project_media')
      .insert(media)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteProjectMedia(id: string) {
    const { error } = await supabase
      .from('project_media')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  // Project social operations
  async addProjectSocial(social: Omit<ProjectSocial, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('project_social')
      .insert(social)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateProjectSocial(id: string, updates: Partial<ProjectSocial>) {
    const { data, error } = await supabase
      .from('project_social')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteProjectSocial(id: string) {
    const { error } = await supabase
      .from('project_social')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  // Tokenization operations
  async createTokenization(tokenization: Omit<Tokenization, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('tokenization')
      .insert(tokenization)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateTokenization(id: string, updates: Partial<Tokenization>) {
    const { data, error } = await supabase
      .from('tokenization')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // Project milestones operations
  async addMilestone(milestone: Omit<ProjectMilestone, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('project_milestones')
      .insert(milestone)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateMilestone(id: string, updates: Partial<ProjectMilestone>) {
    const { data, error } = await supabase
      .from('project_milestones')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteMilestone(id: string) {
    const { error } = await supabase
      .from('project_milestones')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  // Project updates operations
  async addUpdate(update: Omit<ProjectUpdate, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('project_updates')
      .insert(update)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateUpdate(id: string, updates: Partial<ProjectUpdate>) {
    const { data, error } = await supabase
      .from('project_updates')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteUpdate(id: string) {
    const { error } = await supabase
      .from('project_updates')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  // Project comments operations
  async addComment(comment: Omit<ProjectComment, 'id' | 'created_at' | 'updated_at'>) {
    const { data, error } = await supabase
      .from('project_comments')
      .insert(comment)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateComment(id: string, updates: Partial<ProjectComment>) {
    const { data, error } = await supabase
      .from('project_comments')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteComment(id: string) {
    const { error } = await supabase
      .from('project_comments')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  // File upload operations
  async uploadFile(bucket: string, path: string, file: File) {
    try {
      // Use the S3 service instead of Supabase client
      const publicUrl = await s3Service.uploadFile(bucket, path, file);
      
      // Return the URL directly
      return publicUrl;
    } catch (error) {
      console.error(`Error uploading file to ${bucket}:`, error);
      throw error;
    }
  },

  async getFileUrl(bucket: string, path: string) {
    const publicUrl = `https://${import.meta.env.VITE_SUPABASE_PROJECT_ID}.supabase.co/storage/v1/object/public/${bucket}/${path}`;
    return publicUrl;
  },

  async deleteFile(bucket: string, path: string) {
    try {
      await s3Service.deleteFile(bucket, path);
    } catch (error) {
      console.error(`Error deleting file from ${bucket}:`, error);
      throw error;
    }
  }
}; 