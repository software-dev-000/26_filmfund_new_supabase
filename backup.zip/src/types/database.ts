export interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  user_type: 'filmmaker' | 'investor';
  created_at: string;
  updated_at: string;
}

export interface Project {
  id: string;
  filmmaker_id: string;
  title: string;
  tagline: string;
  genre: string;
  category: 'feature' | 'short' | 'series' | 'documentary';
  funding_goal: number;
  duration: number;
  stable_split: number;
  synopsis: string;
  description: string;
  cover_image: string;
  status: 'draft' | 'funding' | 'production' | 'completed';
  created_at: string;
  updated_at: string;
}

export interface TeamMember {
  id: string;
  project_id: string;
  name: string;
  role: string;
  bio: string;
  image_url?: string;
  created_at: string;
  updated_at: string;
}

export interface ProjectMedia {
  id: string;
  project_id: string;
  type: 'image' | 'document';
  url: string;
  created_at: string;
}

export interface ProjectSocial {
  id: string;
  project_id: string;
  platform: 'website' | 'twitter' | 'instagram';
  url: string;
  created_at: string;
}

export interface Tokenization {
  id: string;
  project_id: string;
  jurisdiction: string;
  legal_advisor: string;
  tokenized_assets: string[];
  security_type: string;
  max_supply: number;
  token_symbol: string;
  blockchain: string;
  lockup_period: number;
  enable_dividends: boolean;
  trading_option: string;
  whitelist_only: boolean;
  token_price: number;
  custom_terms: string;
  vesting_start_date: string;
  vesting_duration: number;
  cliff_period: number;
  require_kyc_aml: boolean;
  accredited_only: boolean;
  distribution_method: string;
  secondary_market: string;
  spv_name: string;
  created_at: string;
  updated_at: string;
}

export interface Investment {
  id: string;
  project_id: string;
  investor_id: string;
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  created_at: string;
  updated_at: string;
}

export interface ProjectMilestone {
  id: string;
  project_id: string;
  title: string;
  description: string;
  due_date: string;
  status: 'pending' | 'in_progress' | 'completed';
  created_at: string;
  updated_at: string;
}

export interface ProjectUpdate {
  id: string;
  project_id: string;
  title: string;
  content: string;
  created_at: string;
  updated_at: string;
}

export interface ProjectComment {
  id: string;
  project_id: string;
  user_id: string;
  content: string;
  created_at: string;
  updated_at: string;
} 